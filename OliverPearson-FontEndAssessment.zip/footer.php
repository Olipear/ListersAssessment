<footer>
 A footer
</footer>